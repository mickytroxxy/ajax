$(document).on("click",".clickMe",  function(e) {
    //call the below function when you want to add/delete/select/update data from the server.
    //The below function will give you an alert once connected to the server. 
    //You see its calling serverConnect function with the first argument being empty. 
    //This is to test your ajax. when you want to do some stuffs you will call serverConnect with some arguments
    serverConnect('',function(result){
        alert(result)
    });
    //for example you can use the below code to register a user.
    /*var fname ='Client Name';
    var lname = 'Client lastname';
    var password ='client password';
    serverConnect('registerfname/'+fname+'/registerlname/'+lname+'/registerPass/'+password,function(result){
        alert(result)
    });*/
});


function serverConnect(params,cb){
   //This is a function that connects to the server. 
   //The result argument there is the data returned from the server that you can use to populate your interface.
   //The result will be in json format
   //The params argument + the url below makes the full url that can be send to the server.
   //In other words you will be passing the url to the server. The url can be different according to your needs.
   //Example of the url will look like this  
   //http://ec2-13-58-254-234.us-east-2.compute.amazonaws.com:4000/identifier/variable/anotherIdentifier/anotherVariable
   $.ajax({url: 'http://ec2-13-58-254-234.us-east-2.compute.amazonaws.com:4000/'+params}).done(function (result) {
        cb(result)
    }); 
}